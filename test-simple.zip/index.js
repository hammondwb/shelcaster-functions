const { DynamoDBClient, GetItemCommand } = require('@aws-sdk/client-dynamodb');
const { marshall, unmarshall } = require('@aws-sdk/util-dynamodb');

const dynamoDBClient = new DynamoDBClient({ region: 'us-east-1' });

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event));
  
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*'
  };
  
  try {
    const sessionId = event.pathParameters?.sessionId;
    
    if (!sessionId) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Missing sessionId' })
      };
    }
    
    // Get session from DynamoDB
    const sessionResult = await dynamoDBClient.send(new GetItemCommand({
      TableName: 'shelcaster-app',
      Key: marshall({
        pk: `session#${sessionId}`,
        sk: 'info'
      })
    }));
    
    if (!sessionResult.Item) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: 'Session not found' })
      };
    }
    
    const session = unmarshall(sessionResult.Item);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: 'Streaming started (test mode - no actual streaming)',
        session: session
      })
    };
    
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message, stack: error.stack })
    };
  }
};
