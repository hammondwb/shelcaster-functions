const AWS_IVS = require('@aws-sdk/client-ivs');
const AWS_MediaLive = require('@aws-sdk/client-medialive');
const AWS_DynamoDB = require('@aws-sdk/client-dynamodb');
const { marshall, unmarshall } = require('@aws-sdk/util-dynamodb');

const ivsClient = new AWS_IVS.IVSClient({ region: 'us-east-1' });
const mediaLiveClient = new AWS_MediaLive.MediaLiveClient({ region: 'us-east-1' });
const dynamoDBClient = new AWS_DynamoDB.DynamoDBClient({ region: 'us-east-1' });

const TABLE_NAME = 'shelcaster-app';

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*'
  };
  
  try {
    const sessionId = event.pathParameters?.sessionId;
    
    if (!sessionId) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Missing sessionId' })
      };
    }
    
    // Get session from DynamoDB
    const sessionResult = await dynamoDBClient.send(new AWS_DynamoDB.GetItemCommand({
      TableName: TABLE_NAME,
      Key: marshall({
        pk: `session#${sessionId}`,
        sk: 'info'
      })
    }));
    
    if (!sessionResult.Item) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: 'Session not found' })
      };
    }
    
    const session = unmarshall(sessionResult.Item);
    
    // Start MediaLive channel if not already started
    if (session.mediaLive?.channelId) {
      try {
        await mediaLiveClient.send(new AWS_MediaLive.StartChannelCommand({
          ChannelId: session.mediaLive.channelId
        }));
        console.log('MediaLive channel started:', session.mediaLive.channelId);
      } catch (error) {
        if (error.name !== 'ConflictException') {
          throw error;
        }
        console.log('MediaLive channel already running');
      }
    }
    
    // Start IVS channel
    if (session.ivs?.programChannelArn) {
      await ivsClient.send(new AWS_IVS.StartChannelCommand({
        arn: session.ivs.programChannelArn
      }));
      console.log('IVS channel started:', session.ivs.programChannelArn);
    }
    
    // Update DynamoDB
    await dynamoDBClient.send(new AWS_DynamoDB.UpdateItemCommand({
      TableName: TABLE_NAME,
      Key: marshall({
        pk: `session#${sessionId}`,
        sk: 'info'
      }),
      UpdateExpression: 'SET streaming.isLive = :live, streaming.startedAt = :now, updatedAt = :now',
      ExpressionAttributeValues: marshall({
        ':live': true,
        ':now': new Date().toISOString()
      })
    }));
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: 'Streaming started',
        playbackUrl: session.ivs?.programPlaybackUrl
      })
    };
    
  } catch (error) {
    console.error('Error starting streaming:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
