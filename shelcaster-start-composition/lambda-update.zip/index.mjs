import { IVSRealTimeClient, StartCompositionCommand } from "@aws-sdk/client-ivs-realtime";
import { DynamoDBClient, GetItemCommand, UpdateItemCommand } from "@aws-sdk/client-dynamodb";
import { marshall, unmarshall } from "@aws-sdk/util-dynamodb";

const ivsClient = new IVSRealTimeClient({ region: "us-east-1" });
const dynamoDBClient = new DynamoDBClient({ region: "us-east-1" });

export const handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': '*',
  };

  try {
    const { sessionId } = event.pathParameters;

    if (!sessionId) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: "Missing sessionId parameter" }),
      };
    }

    // Get session details
    const getSessionParams = {
      TableName: "shelcaster-app",
      Key: marshall({
        pk: `session#${sessionId}`,
        sk: 'info',
      }),
    };

    const sessionResult = await dynamoDBClient.send(new GetItemCommand(getSessionParams));
    const session = sessionResult.Item ? unmarshall(sessionResult.Item) : null;

    if (!session) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ message: "Session not found" }),
      };
    }

    if (!session.ivs?.programStageArn) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: "Session does not have a PROGRAM stage." }),
      };
    }

    if (!session.ivs?.programChannelArn) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: "Session does not have a PROGRAM channel." }),
      };
    }

    // Start composition on PROGRAM stage with SINGLE layout
    const compositionParams = {
      stageArn: session.ivs.programStageArn,
      destinations: [
        {
          channel: {
            channelArn: session.ivs.programChannelArn,
            encoderConfigurationArn: process.env.ENCODER_CONFIGURATION_ARN, // Optional
          },
        },
        {
          s3: {
            storageConfigurationArn: `arn:aws:ivs:us-east-1:124355640062:storage-configuration/shelcaster-recordings`,
            encoderConfigurationArn: process.env.ENCODER_CONFIGURATION_ARN, // Optional
          },
        },
      ],
      layout: {
        grid: {
          featuredParticipantAttribute: null,
          gridGap: 0,
          omitStoppedVideo: false,
          videoAspectRatio: "VIDEO",
          videoFillMode: "FILL"
        },
      },
    };

    console.log('Starting PROGRAM composition with params:', JSON.stringify(compositionParams, null, 2));

    const compositionResponse = await ivsClient.send(new StartCompositionCommand(compositionParams));
    const compositionArn = compositionResponse.composition.arn;

    console.log('PROGRAM composition started:', compositionArn);

    // Update session with composition ARN
    const updateSessionParams = {
      TableName: "shelcaster-app",
      Key: marshall({
        pk: `session#${sessionId}`,
        sk: 'info',
      }),
      UpdateExpression: 'SET #ivs.#compositionArn = :compositionArn, #streaming.#isLive = :isLive, #recording.#isRecording = :isRecording, #updatedAt = :updatedAt',
      ExpressionAttributeNames: {
        '#ivs': 'ivs',
        '#compositionArn': 'compositionArn',
        '#streaming': 'streaming',
        '#isLive': 'isLive',
        '#recording': 'recording',
        '#isRecording': 'isRecording',
        '#updatedAt': 'updatedAt',
      },
      ExpressionAttributeValues: marshall({
        ':compositionArn': compositionArn,
        ':isLive': true,
        ':isRecording': true,
        ':updatedAt': new Date().toISOString(),
      }),
    };

    await dynamoDBClient.send(new UpdateItemCommand(updateSessionParams));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        compositionArn,
        programStageArn: session.ivs.programStageArn,
        programChannelArn: session.ivs.programChannelArn,
        programPlaybackUrl: session.ivs.programPlaybackUrl,
        message: 'PROGRAM composition started successfully',
      }),
    };
  } catch (error) {
    console.error('Error starting composition:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        message: "Failed to start composition",
        error: error.message,
      }),
    };
  }
};

