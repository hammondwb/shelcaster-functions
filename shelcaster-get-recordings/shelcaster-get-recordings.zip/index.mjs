import { DynamoDBClient, QueryCommand, UpdateItemCommand } from "@aws-sdk/client-dynamodb";
import { S3Client, ListObjectsV2Command, HeadObjectCommand } from "@aws-sdk/client-s3";
import { unmarshall, marshall } from "@aws-sdk/util-dynamodb";

const dynamoDBClient = new DynamoDBClient({ region: "us-east-1" });
const s3Client = new S3Client({ region: "us-east-1" });

const S3_BUCKET = "shelcaster-media-manager";
const CLOUDFRONT_DOMAIN = process.env.CLOUDFRONT_DOMAIN || "d2jyqxlv5zply3.cloudfront.net";

export const handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': '*',
  };

  try {
    const { showId } = event.pathParameters || {};
    const { userId } = event.queryStringParameters || {};

    // If showId is provided, get recordings for that show
    if (showId) {
      return await getShowRecordings(showId, headers);
    }

    // If userId is provided, get all recordings for that user's shows
    if (userId) {
      return await getUserRecordings(userId, headers);
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ message: "Missing showId or userId parameter" }),
    };
  } catch (error) {
    console.error("Error getting recordings:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: "Internal server error", error: error.message }),
    };
  }
};

async function getShowRecordings(showId, headers) {
  try {
    // Query DynamoDB for recording metadata
    const params = {
      TableName: "shelcaster-app",
      KeyConditionExpression: "pk = :pk AND begins_with(sk, :sk)",
      ExpressionAttributeValues: {
        ":pk": { S: `show#${showId}` },
        ":sk": { S: "recording#" }
      }
    };

    const result = await dynamoDBClient.send(new QueryCommand(params));
    let recordings = result.Items ? result.Items.map(item => unmarshall(item)) : [];

    // If no recordings in DB, check S3 for any recordings
    if (recordings.length === 0) {
      const s3Recordings = await scanS3ForRecordings(showId);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          recordings: s3Recordings,
          source: 's3-scan'
        }),
      };
    }

    // Check for stuck "processing" recordings and try to find their S3 files
    const updatedRecordings = [];
    for (const recording of recordings) {
      if (recording.status === 'processing') {
        console.log(`Checking S3 for stuck recording: ${recording.recordingId}, channelArn: ${recording.channelArn}`);

        let s3Data = null;

        // Try to find by channel ARN first
        if (recording.channelArn) {
          s3Data = await findRecordingInS3ByChannel(recording.channelArn);
        }

        // If no channelArn or not found, try to match by recording start time
        if (!s3Data && recording.startTime) {
          console.log(`No channelArn, trying to find by timestamp: ${recording.startTime}`);
          s3Data = await findRecordingInS3ByTimestamp(recording.startTime);
        }

        if (s3Data) {
          console.log(`Found S3 data for recording ${recording.recordingId}:`, s3Data);
          // Update the recording in DynamoDB
          const updated = await updateRecordingToCompleted(recording, s3Data);
          updatedRecordings.push(updated || recording);
        } else {
          console.log(`No S3 data found for recording ${recording.recordingId}`);
          updatedRecordings.push(recording);
        }
      } else {
        updatedRecordings.push(recording);
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ recordings: updatedRecordings }),
    };
  } catch (error) {
    console.error("Error getting show recordings:", error);
    throw error;
  }
}

async function getUserRecordings(userId, headers) {
  try {
    // First, get all shows for this user
    const showsParams = {
      TableName: "shelcaster-app",
      IndexName: "GSI1",
      KeyConditionExpression: "GSI1PK = :gsi1pk",
      ExpressionAttributeValues: {
        ":gsi1pk": { S: `producer#${userId}` }
      }
    };

    const showsResult = await dynamoDBClient.send(new QueryCommand(showsParams));
    const shows = showsResult.Items ? showsResult.Items.map(item => unmarshall(item)) : [];

    // Get recordings for each show
    const allRecordings = [];
    for (const show of shows) {
      const recordingsParams = {
        TableName: "shelcaster-app",
        KeyConditionExpression: "pk = :pk AND begins_with(sk, :sk)",
        ExpressionAttributeValues: {
          ":pk": { S: `show#${show.showId}` },
          ":sk": { S: "recording#" }
        }
      };

      const recordingsResult = await dynamoDBClient.send(new QueryCommand(recordingsParams));
      const recordings = recordingsResult.Items ? recordingsResult.Items.map(item => unmarshall(item)) : [];
      
      allRecordings.push(...recordings.map(rec => ({
        ...rec,
        showTitle: show.title,
        showId: show.showId
      })));
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ recordings: allRecordings }),
    };
  } catch (error) {
    console.error("Error getting user recordings:", error);
    throw error;
  }
}

async function scanS3ForRecordings(showId) {
  try {
    // IVS recordings are stored in: ivs-recordings/{channel-id}/{year}/{month}/{day}/...
    // We need to scan the bucket for recordings related to this show
    const prefix = `ivs-recordings/`;
    
    const listParams = {
      Bucket: S3_BUCKET,
      Prefix: prefix,
      MaxKeys: 1000
    };

    const result = await s3Client.send(new ListObjectsV2Command(listParams));
    
    if (!result.Contents || result.Contents.length === 0) {
      return [];
    }

    // Group recordings by session (find master.m3u8 files)
    const recordings = [];
    const masterFiles = result.Contents.filter(obj => obj.Key.endsWith('master.m3u8'));

    for (const masterFile of masterFiles) {
      const recordingPath = masterFile.Key;
      const pathParts = recordingPath.split('/');
      
      recordings.push({
        recordingId: pathParts.slice(0, -2).join('/'), // Remove /media/hls/master.m3u8
        s3Key: recordingPath,
        s3Bucket: S3_BUCKET,
        size: masterFile.Size,
        lastModified: masterFile.LastModified,
        playbackUrl: `https://${S3_BUCKET}.s3.amazonaws.com/${recordingPath}`
      });
    }

    return recordings;
  } catch (error) {
    console.error("Error scanning S3 for recordings:", error);
    return [];
  }
}

// Find IVS recording in S3 by channel ARN
async function findRecordingInS3ByChannel(channelArn) {
  try {
    // Extract channel ID from ARN: arn:aws:ivs:us-east-1:123456789:channel/abcd1234
    const channelId = channelArn.split('/').pop();
    if (!channelId) {
      console.log('Could not extract channel ID from ARN:', channelArn);
      return null;
    }

    // IVS recordings are stored in: ivs/v1/{account}/{channel_id}/...
    const prefix = `ivs/`;

    const listParams = {
      Bucket: S3_BUCKET,
      Prefix: prefix,
      MaxKeys: 1000
    };

    const result = await s3Client.send(new ListObjectsV2Command(listParams));

    if (!result.Contents || result.Contents.length === 0) {
      console.log('No objects found in S3 with prefix:', prefix);
      return null;
    }

    // Find master.m3u8 files that contain the channel ID
    const masterFiles = result.Contents.filter(obj =>
      obj.Key.endsWith('master.m3u8') && obj.Key.includes(channelId)
    );

    if (masterFiles.length === 0) {
      console.log('No master.m3u8 found for channel:', channelId);
      return null;
    }

    // Use the most recent master file
    const masterFile = masterFiles.sort((a, b) =>
      new Date(b.LastModified) - new Date(a.LastModified)
    )[0];

    const playbackUrl = `https://${CLOUDFRONT_DOMAIN}/${masterFile.Key}`;

    return {
      s3Key: masterFile.Key,
      s3Bucket: S3_BUCKET,
      playbackUrl,
      size: masterFile.Size || 0
    };
  } catch (error) {
    console.error('Error finding recording in S3:', error);
    return null;
  }
}

// Find IVS recording in S3 by timestamp (fallback when no channelArn)
async function findRecordingInS3ByTimestamp(startTime) {
  try {
    const recordingDate = new Date(startTime);

    // Build prefix based on IVS recording path structure: ivs/v1/{account}/{channel_id}/{year}/{month}/{day}/{hour}/...
    const year = recordingDate.getUTCFullYear();
    const month = recordingDate.getUTCMonth() + 1;
    const day = recordingDate.getUTCDate();
    const hour = recordingDate.getUTCHours();

    // List all recordings and find the one closest to our timestamp
    const prefix = `ivs/`;

    const listParams = {
      Bucket: S3_BUCKET,
      Prefix: prefix,
      MaxKeys: 1000
    };

    const result = await s3Client.send(new ListObjectsV2Command(listParams));

    if (!result.Contents || result.Contents.length === 0) {
      console.log('No objects found in S3 with prefix:', prefix);
      return null;
    }

    // Find all master.m3u8 files
    const masterFiles = result.Contents.filter(obj => obj.Key.endsWith('master.m3u8'));

    if (masterFiles.length === 0) {
      console.log('No master.m3u8 found in S3');
      return null;
    }

    console.log(`Found ${masterFiles.length} master.m3u8 files`);

    // Find the file with the closest timestamp to our recording start
    let bestMatch = null;
    let smallestDiff = Infinity;

    for (const file of masterFiles) {
      // Path: ivs/v1/{account}/{channel}/{year}/{month}/{day}/{hour}/{recording_id}/media/hls/master.m3u8
      const pathParts = file.Key.split('/');
      if (pathParts.length >= 8) {
        const fileYear = parseInt(pathParts[4]);
        const fileMonth = parseInt(pathParts[5]);
        const fileDay = parseInt(pathParts[6]);
        const fileHour = parseInt(pathParts[7]);

        const fileDate = new Date(Date.UTC(fileYear, fileMonth - 1, fileDay, fileHour));
        const diff = Math.abs(recordingDate.getTime() - fileDate.getTime());

        // If within 2 hours of the recording start time, consider it a match
        if (diff < 2 * 60 * 60 * 1000 && diff < smallestDiff) {
          smallestDiff = diff;
          bestMatch = file;
        }
      }
    }

    if (!bestMatch) {
      // Just return the most recent master file as fallback
      bestMatch = masterFiles.sort((a, b) =>
        new Date(b.LastModified) - new Date(a.LastModified)
      )[0];
      console.log('No timestamp match, using most recent recording');
    }

    const playbackUrl = `https://${CLOUDFRONT_DOMAIN}/${bestMatch.Key}`;

    return {
      s3Key: bestMatch.Key,
      s3Bucket: S3_BUCKET,
      playbackUrl,
      size: bestMatch.Size || 0
    };
  } catch (error) {
    console.error('Error finding recording in S3 by timestamp:', error);
    return null;
  }
}

// Update a recording from "processing" to "completed"
async function updateRecordingToCompleted(recording, s3Data) {
  try {
    const now = new Date().toISOString();

    const updateParams = {
      TableName: "shelcaster-app",
      Key: marshall({
        pk: recording.pk,
        sk: recording.sk
      }),
      UpdateExpression: 'SET #status = :status, s3Key = :s3Key, s3Bucket = :s3Bucket, playbackUrl = :playbackUrl, #size = :size, updatedAt = :updatedAt',
      ExpressionAttributeNames: {
        '#status': 'status',
        '#size': 'size'
      },
      ExpressionAttributeValues: marshall({
        ':status': 'completed',
        ':s3Key': s3Data.s3Key,
        ':s3Bucket': s3Data.s3Bucket,
        ':playbackUrl': s3Data.playbackUrl,
        ':size': s3Data.size,
        ':updatedAt': now
      }),
      ReturnValues: 'ALL_NEW'
    };

    const result = await dynamoDBClient.send(new UpdateItemCommand(updateParams));
    console.log('Updated recording to completed:', recording.recordingId);

    return unmarshall(result.Attributes);
  } catch (error) {
    console.error('Error updating recording to completed:', error);
    return null;
  }
}
